
<html>
<head>
    
    <title>Edit Advertiser Profile</title>
    <link rel="stylesheet" href="../../../asset/css/shohan_css_files/edit_profile.css">
</head>
<body>

    <div class="form-container">
        <h1>Edit Profile (Advertiser)</h1>
        <form action="" method="">
            <div class="form-section">
                <label for="business-name">Edit Business Name</label>
                <input type="text" id="business-name" name="business-name" value="">
            </div>

            <div class="form-section">
                <label for="contact-email">Edit Contact Email</label>
                <input type="email" id="contact-email" name="contact-email" value="">
            </div>

            <button type="submit">Update Profile</button>
            <button type="button" onclick="window.history.back();">Go Back</button>
        </form>
    </div>

</body>
</html>